- Code is run as specified in the assignment. 
  I kept the 'official-data' folder intact so to run it on the provided data from the home directory just specify:
  python3 feature_extraction.py ./official-data/big-example/train.txt ./official-data/big-example/test.txt 
- I tested it on lab2-11.
- None that I've found.
