(a) I used python 3.8
(b) To get sentence probabilities run: python3 langmodels.py <train_file> -test <test_file>
    To generate new sentences run:     python3 langmodels.py <train_file> -gen <seed_file>
(c) lab1-19
(d) I'm not sure how long it is acceptable for the program to run on train2.txt, but
    my program takes on the order of 10 minutes for the larger training file.
