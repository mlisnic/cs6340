python3 morphology.py sampleDict.txt sampleRules.txt sampleTest.txt
